# Ansible Role: vector

[![License](https://img.shields.io/badge/license-MIT%20License-brightgreen.svg)](https://opensource.org/licenses/MIT)
[![GitHub tag](https://img.shields.io/github/v/tag/Yacuba/vector-role)](https://github.com/Yacuba/vector-role/tags)

## Description

Deploy and configure [Vector](https://vector.dev) — a high-performance observability data pipeline for collecting, transforming, and routing logs and metrics on Linux systems.

## Requirements

- **Ansible** >= 2.10
- **Target OS**:
  - Enterprise Linux (RHEL / AlmaLinux / Rocky Linux / CentOS 8/9)
- **Privileges**: Root access on the remote host (`become: true`)

## Role Variables

All variables that can be overridden are stored in [defaults/main.yml](defaults/main.yml).

### Default Variables (`defaults/main.yml`)

| Variable | Default Value | Description |
| :--- | :--- | :--- |
| `vector_version` | `"0.38.0"` | Vector release version to install from official distribution. |
| `vector_config_dir` | `"/etc/vector"` | Destination directory for Vector configuration files. |
| `vector_data_dir` | `"/var/lib/vector"` | Working directory for Vector internal state, on-disk buffers, and sink checkpoints. |

### Internal Variables (`vars/main.yml`)

These variables are defined in [vars/main.yml](vars/main.yml) and define system-level paths and package sources:

| Variable | Value | Description |
| :--- | :--- | :--- |
| `vector_install_dir` | `"/opt/vector"` | Directory where the binary archive is unpacked. |
| `vector_bin_path` | `"/usr/bin/vector"` | Path to the system binary symlink. |
| `vector_service_path`| `"/etc/systemd/system/vector.service"` | Path to the systemd service unit. |
| `vector_package_arch`| `"x86_64-unknown-linux-musl"` | Platform target architecture. |
| `vector_archive` | `"vector-{{ vector_version }}-{{ vector_package_arch }}.tar.gz"` | Distribution archive filename. |
| `vector_url` | `"https://packages.timber.io/vector/{{ vector_version }}/{{ vector_archive }}"` | URL for downloading the release tarball. |

## Dependencies

None.

## Example Playbook

An example of how to use this role in an Ansible playbook:

```yaml
---
- name: Install and configure Vector
  hosts: vector
  roles:
    - role: vector-role
      vars:
        vector_version: "0.38.0"
        vector_config_dir: "/etc/vector"
```

## Handlers

The role includes a handler to restart the service and reload the systemd daemon:
* `Restart Vector service`

## License

This project is licensed under the MIT License.

## Author Information

Created by [Yacuba](https://github.com/Yacuba).