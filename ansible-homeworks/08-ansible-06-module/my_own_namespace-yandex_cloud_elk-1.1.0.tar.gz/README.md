# Ansible Collection: my_own_namespace.yandex_cloud_elk

This collection contains custom Ansible modules, roles, and playbooks for cloud provisioning and observability stack deployment.

## Included Content

### Modules
* `my_own_namespace.yandex_cloud_elk.my_own_module`: Creates or updates a file with specified content, supporting idempotency and check mode.
* `my_own_namespace.yandex_cloud_elk.yc_instance`: Manages Yandex Cloud compute instances via `yc` CLI with full idempotency support.

### Roles
* `my_own_namespace.yandex_cloud_elk.site_file`: A single-task role utilizing `my_own_module`.
* `my_own_namespace.yandex_cloud_elk.vector`: Deploys and configures Vector log collector service.
* `my_own_namespace.yandex_cloud_elk.lighthouse`: Deploys LightHouse web UI on top of Nginx web server.

### Playbooks
* `playbooks/deploy_observability.yml`: Demonstrates automated end-to-end deployment of an Observability stack in Yandex Cloud.

## Usage Example

```bash
ansible-playbook -i localhost, my_own_namespace.yandex_cloud_elk.deploy_observability
```