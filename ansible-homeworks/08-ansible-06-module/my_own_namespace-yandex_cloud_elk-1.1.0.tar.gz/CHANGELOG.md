# Changelog

## 1.1.0

### Major Changes
- Added `yc_instance` module for managing Yandex Cloud compute instances.
- Added `vector` and `lighthouse` roles.
- Added `deploy_observability.yml` playbook.

## 1.0.0

### Major Changes
- Initial release of `my_own_namespace.yandex_cloud_elk` collection.
- Added `my_own_module` and `site_file` role.