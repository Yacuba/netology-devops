# Ansible Collection: my_own_namespace.yandex_cloud_elk

This collection contains custom Ansible modules and roles developed for educational and automation purposes.

## Included Content

### Modules
* `my_own_namespace.yandex_cloud_elk.my_own_module`: Creates or updates a file with specified content, fully supporting idempotency and check mode.

### Roles
* `my_own_namespace.yandex_cloud_elk.site_file`: A single-task role utilizing `my_own_module` with default parameters.

## Usage Example

```yaml
---
- name: Apply collection role
  hosts: localhost
  gather_facts: false
  roles:
    - role: my_own_namespace.yandex_cloud_elk.site_file
      vars:
        site_file_path: "/tmp/custom_file.txt"
        site_file_content: "Customized content from playbook"